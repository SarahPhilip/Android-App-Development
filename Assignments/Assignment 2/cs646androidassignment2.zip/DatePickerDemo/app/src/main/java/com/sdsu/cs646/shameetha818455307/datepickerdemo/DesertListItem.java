package com.sdsu.cs646.shameetha818455307.datepickerdemo;

/**
 * Created by Shameetha on 2/13/15.
 */
public class DesertListItem {
    private String itemTitle;
    public String getItemTitle() {
        return itemTitle;
    }
    public void setItemTitle(String itemTitle) {
        this.itemTitle = itemTitle;
    }
    public DesertListItem(String title){
        this.itemTitle = title;
    }
}
