package com.sdsu.cs646.shameetha818455307.assignment_1;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class LifeCycleActivity extends ActionBarActivity {

    private TextView mLogTextView;
    private TextView mScrollView;
    private static final String TAG = "LogActivity";
    private static final String KEY_INDEX = "log";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, getString(R.string.on_create));
        setContentView(R.layout.activity_life_cycle);

        mLogTextView = (TextView)findViewById(R.id.log_text_view);
        mLogTextView.append(getString(R.string.on_create)+"\n");

        String restoredText = getValue();

        Button mClearButton;
        mClearButton = (Button)findViewById(R.id.clear_button);
        mClearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(LifeCycleActivity.this,
                        R.string.clear_toast,
                        Toast.LENGTH_SHORT).show();
                mLogTextView = (TextView)findViewById(R.id.log_text_view);
                mLogTextView.getEditableText().clear();
                clearData();
            }
        });
        if (restoredText != null) {
            mLogTextView.setText(restoredText);
            mLogTextView.append(getString(R.string.on_create)+"\n");
        }
        if (savedInstanceState != null) {
            mLogTextView.setText(savedInstanceState.getString(KEY_INDEX));
            mLogTextView.append(getString(R.string.on_create)+"\n");
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, getString(R.string.on_restart));
        mLogTextView = (TextView)findViewById(R.id.log_text_view);
        mLogTextView.append(getString(R.string.on_restart)+"\n");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, getString(R.string.on_start));
        mLogTextView = (TextView)findViewById(R.id.log_text_view);
        mLogTextView.append(getString(R.string.on_start)+"\n");
    }

    @Override
    protected void onStop() {
        super.onStop();
        save();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, getString(R.string.on_pause));
        mLogTextView = (TextView)findViewById(R.id.log_text_view);
        mLogTextView.append(getString(R.string.on_pause)+"\n");
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        Log.d(TAG, getString(R.string.on_saveInstanceState));
        mLogTextView = (TextView)findViewById(R.id.log_text_view);
        mLogTextView.append(getString(R.string.on_saveInstanceState)+"\n");
        savedInstanceState.putString(KEY_INDEX, mLogTextView.getText().toString());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.d(TAG, getString(R.string.on_restoreInstanceState));
        mLogTextView = (TextView)findViewById(R.id.log_text_view);
        mLogTextView.append(getString(R.string.on_restoreInstanceState)+"\n");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, getString(R.string.on_resume));
        mLogTextView = (TextView)findViewById(R.id.log_text_view);
        mLogTextView.append(getString(R.string.on_resume)+"\n");
        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_life_cycle, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void save() {
        SharedPreferences.Editor editor = getPreferences(MODE_PRIVATE).edit();
        editor.putString(KEY_INDEX, mLogTextView.getText().toString());
        editor.apply();
    }
    public String getValue() {
        String savedText;
        SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        savedText = prefs.getString(KEY_INDEX, null);
        return savedText;
    }
    public void clearData() {
        SharedPreferences.Editor editor = getPreferences(MODE_PRIVATE).edit();
        editor.putString(KEY_INDEX, mLogTextView.getText().toString());
        editor.clear();
        editor.apply();
    }
}